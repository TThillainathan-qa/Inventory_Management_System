package code;

import java.sql.SQLException;

import java.util.Scanner;

public class App {
	
	public static void main (String[] arg) throws SQLException {
		
		DB db = new DB();
		User customer = new User();
		System.out.println("_______________________________________________\n");
		System.out.println("Welcome To My Shop");
		System.out.println("_______________________________________________\n");
		customer.mainMenu();
	
	
		
	}
}
		
		
	


