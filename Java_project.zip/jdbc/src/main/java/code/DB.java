package code;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DB {

	
	private Connection conn;
	
	private Statement stmnt;
	//-----------------------Database Connection-------------//
	// Connecting to mysql database 
	public Connection getConnection() throws SQLException{
		try {
			conn = DriverManager.getConnection(DBConfig.URL, DBConfig.USER, DBConfig.PASSWORD);
			System.out.println("Connected to Database");
		
		}catch(SQLException e) {
			System.out.println("failed");
			
		}
		
		return conn;
		
	}
	
	//----------------Customer Table----------------------//
	
	//Create new Customer
	
	public void createCustomer(int customerid, String firstname, String lastname, String address, String email, int age, int contactNo, String city) throws SQLException {
		this.stmnt = conn.createStatement();
		String sql = "INSERT INTO customer (customerID, first_name, last_name, address, email, age, contact_number, city) VALUES (" 
		+ customerid +",\""+ firstname +"\", \"" + lastname +"\", \""+address +"\", \""+  email +"\", \"" +age+"\", \"" +contactNo +"\", \""+city +"\")";
		System.out.println(sql);
		stmnt.executeUpdate(sql);
	}


	//Delete customer
	public void deleteCustomer(int customerID) throws SQLException {
		String delete = "DELETE FROM customer WHERE customerID = " + customerID + "";
		stmnt.executeUpdate(delete);
	}
	
	
	// Read customer Table 
	public void read() throws SQLException {
		this.stmnt = conn.createStatement();
		String sql = "SELECT * FROM customer";
		ResultSet results =this.stmnt.executeQuery(sql );
		while (results.next()) {
				String read = results.getInt("customerID") + "   |" +results.getString("first_name") +"  | "+ results.getString("last_name")+"    |"+ results.getString("address") +"  |"+
				results.getString("email");
			System.out.println(read);
		}
	}
	
	
	
	

	
		
		// update 
		public void updateCustomer(int customerID, String firstname, String lastname, String address, String email , int age, int contact_number, String city) throws SQLException {
			
			String update = "UPDATE customers SET first_name = '" + firstname + "', last_name = '" + lastname + "', address = '" + address +"', email = '" + email +"', age = '" + age + "', contact_number = '" + contact_number +"', city = '" + city  +"'WHERE customerID = '" + customerID + "'";    
			stmnt.executeUpdate(update); 

		}
		
	// -----------------------------Product Table-------------------------//
		
		
		//Read All the products name and price
		public void readProduct() throws SQLException {
			this.stmnt = conn.createStatement();
			String sql = "SELECT * FROM item";
			ResultSet results =this.stmnt.executeQuery(sql );
			while (results.next()) {
				String itemsInfo = results.getString("item_name") + " "+ results.getString("price");
				System.out.println(itemsInfo);
			}
		}
		
		//Read All Product Details
		
		public void readFullProduct() throws SQLException {
			this.stmnt = conn.createStatement();
			String sql = "SELECT * FROM item";
			ResultSet results =this.stmnt.executeQuery(sql );
			while (results.next()) {
				String itemsInfo = results.getInt("itemID") + "  " +results.getString("item_name") + " "+ results.getString("price") + results.getString("quantity");
				System.out.println(itemsInfo);
			}
		}
	
	
		//Create a product
		
		public void createProduct(int itemid, String name, int quantity, double price) throws SQLException {
			this.stmnt = conn.createStatement();
			String sql = "INSERT INTO item (itemID, item_name, quantity,price) VALUES (" 
			+ itemid +",\""+ name +"\", \"" + quantity +"\", \""+price +"\")";
			System.out.println(sql);
			stmnt.executeUpdate(sql);
		}
	
		// update 
				public void updateProduct(int itemid, String name, int quantity, double price) throws SQLException {
					
					String update = "UPDATE item SET item_name = '" + name + "', quantity = '" + quantity + "', price = '" + price +"'WHERE customerID = '" + itemid + "'";    
					stmnt.executeUpdate(update); 

				}
				
				//Delete 
				public void deleteProduct(int itemid) throws SQLException {
					String delete = "DELETE FROM item WHERE itemID = " + itemid + "";
					stmnt.executeUpdate(delete);
				}
				
				
				// -----------------------------Order Table-------------------------//
				
				
				//Read Order Details
				public void readOrder() throws SQLException {
					this.stmnt = conn.createStatement();
					String sql = "SELECT * FROM orders";
					ResultSet results =this.stmnt.executeQuery(sql );
					while (results.next()) {
						String itemsInfo = results.getString("orderID") + "  |"+ results.getString("itemID") +"  |" + results.getString("customerID") + "  |" + results.getDate("order_date");
						System.out.println(itemsInfo);
					}
				}
				
			
				//Create an order
				
				public void createOrder(int orderId, int customerId, int itemId) throws SQLException {
					this.stmnt = conn.createStatement();
					String sql = "INSERT INTO orders (orderID, customerID, itemID) VALUES (" 
					+ orderId +",\""+ customerId +"\", \"" + itemId +"\")";
					System.out.println(sql);
					stmnt.executeUpdate(sql);
				}
			
				// update 
						public void updateOrders(int orderId, int customerId, int itemId) throws SQLException {
							
							String update = "UPDATE item SET customerID = '" + customerId + "', itemID = '" + itemId +"'WHERE orderID = '" + orderId + "'";    
							stmnt.executeUpdate(update); 

						}
						
						//Delete 
						public void deleteOrder(int orderId) throws SQLException {
							String delete = "DELETE FROM item WHERE orderID = " + orderId + "";
							stmnt.executeUpdate(delete);
						}
		}

