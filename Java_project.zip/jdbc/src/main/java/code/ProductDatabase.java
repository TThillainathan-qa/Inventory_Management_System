package code;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ProductDatabase {

	private Connection conn;
	private Statement stmnt;
	private DB db;

	public ProductDatabase() throws SQLException {
		db = new DB();
		db.getConnection();

	}
	
	
	

	// -----------------------------Product Table-------------------------//
		
		
		//Read All the products name and price
		public void readProduct() throws SQLException {
			this.stmnt = conn.createStatement();
			String sql = "SELECT * FROM item";
			ResultSet results =this.stmnt.executeQuery(sql );
			while (results.next()) {
				String itemsInfo = results.getString("item_name") + " "+ results.getString("price");
				System.out.println(itemsInfo);
			}
		}
		
		//Read All Product Details
		
		public void readFullProduct() throws SQLException {
			this.stmnt = conn.createStatement();
			String sql = "SELECT * FROM item";
			ResultSet results =this.stmnt.executeQuery(sql );
			while (results.next()) {
				String itemsInfo = results.getInt("itemID") + "  " +results.getString("item_name") + " "+ results.getString("price") + results.getString("quantity");
				System.out.println(itemsInfo);
			}
		}
	
	
		//Create a product
		
		public void createProduct(int itemid, String name, int quantity, double price) throws SQLException {
			this.stmnt = conn.createStatement();
			String sql = "INSERT INTO item (itemID, item_name, quantity,price) VALUES (" 
			+ itemid +",\""+ name +"\", \"" + quantity +"\", \""+price +"\")";
			System.out.println(sql);
			stmnt.executeUpdate(sql);
		}
	
		// update 
				public void updateProduct(int itemid, String name, int quantity, double price) throws SQLException {
					
					String update = "UPDATE item SET item_name = '" + name + "', quantity = '" + quantity + "', price = '" + price +"'WHERE customerID = '" + itemid + "'";    
					stmnt.executeUpdate(update); 

				}
				
				//Delete 
				public void deleteProduct(int itemid) throws SQLException {
					String delete = "DELETE FROM item WHERE itemID = " + itemid + "";
					stmnt.executeUpdate(delete);
				}
}

