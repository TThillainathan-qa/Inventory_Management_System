package code;

import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

public class User {
	

	private DB database;

	private Scanner input = new Scanner(System.in);
	
	
	
	
	public User()throws SQLException{
		database = new DB();
		
			
	}
	
	//--------------Admin Functions------------------------//
	
	//main menu 
	
	public void mainMenu() throws SQLException {
		System.out.println("Choose 1 for Customer \n"+ "Choose 2 for Admin");
		String option = input.nextLine();
		switch(option) {
		case "1":
			customerMenu();
			break;
		
		case "2":
			System.out.println("_________________________________________________\n");
			System.out.println("Welcome To Admin page\n");
			System.out.println("_________________________________________________\n");
			adminFirstPage();
			break;
		}
			
	}
	
	
	// First Page
	private void adminFirstPage() throws SQLException {
		System.out.println("Choose 1 for Customers\n" + "Choose 2 for Products \n"+ "Choose 3 for orders\n" +"Choose 0 to go back");
		String option = input.nextLine();
		
		switch(option) {
		case"0":
			mainMenu();
			break;
			
		case "1":
			customerTable();
			break;
		
		case"2":
			productTable();
			break;
		
		case"3":
			orderTable();
			}
		
	}

	//___________________________________________________Customers ________________________________
	private void customerTable() throws SQLException {
		System.out.println("0. Back \n" + "1. Read Customer Table\n" + "2. Create Customer\n" + " 3.Update Customer Details\n" + " 4 .Delete customer");
		String options = input.nextLine();
		
		switch(options) {
		case "0":
			adminFirstPage();
			break;
		
		case "1":
			readCustomer();
			break;
			
		
		case "2":
			createCustomer();
			break;
			
		case "3":
			updateCustomer();
			break;
		case "4":
			deleteCustomer();
			
		}
		
		
	}
	
	//delete Customer

	private void deleteCustomer() throws SQLException {
		
		System.out.println("Enter the customer ID to delete the customer");
		int id = input.nextInt();
		input.nextLine();
		database.deleteCustomer(id);
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			customerTable();
		}
		
	}
	
	//read 

	private void readCustomer() throws SQLException {
		database.getConnection();
		database.read();
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			customerTable();
		}
		
	}
	
	//create

	private void createCustomer() throws SQLException {
		System.out.println("Customer ID :");
		int customerid = input.nextInt();
		input.nextLine();
		
		System.out.println("FirstName :");
		String firstname = input.nextLine();
		
		System.out.println("LastName : ");
		String lastname = input.nextLine();
		
		System.out.println("Address:");
		String address = input.nextLine();
		
		System.out.println("Email:");
		String email = input.nextLine();
		
		System.out.println("Age:");
		int age = input.nextInt();
		input.nextLine();
		
		System.out.println("Contact Number :");
		int contactNo = input.nextInt();
		input.nextLine();
		
		System.out.println("City : ");
		String city = input.nextLine();
		
		database.getConnection();
		database.createCustomer(customerid, firstname, lastname, address, email, age, contactNo, city);
		System.out.println("Created");
		
		
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			customerTable();
		}
		
	}
	
	// update info

	public void updateDetails() throws SQLException {

		System.out.println("Firstname: ");
		String firstname = input.nextLine();

		System.out.println("Lastname: ");
		String lastname = input.nextLine();

		System.out.println("Email:");
		String email = input.nextLine();

		System.out.println("Age:");
		int age = input.nextInt();
		input.nextLine();

		System.out.println("Contact Number :");
		int contactNo = input.nextInt();
		input.nextLine();

		System.out.println("City : ");
		String city = input.nextLine();

		System.out.println("Enter your New Address");
		String address = input.nextLine();

		System.out.println("Enter your customer id");
		int customerID = input.nextInt();
		input.nextLine();

		database.updateCustomer(customerID, firstname, lastname, address, email, age, contactNo, city);
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			customerTable();
		}

	}


	//_________________________________Products_______________________________
		private void productTable() throws SQLException {
			System.out.println("0. Back \n" + "1. Read Products Table\n" + "2. Create a Product\n" + " 3.Update Product Details\n" + " 4 .Delete Product");
			String options = input.nextLine();
			
			switch(options) {
			case "0":
				adminFirstPage();
				break;
			
			case "1":
				readProduct();
				break;
				
			
			case "2":
				createProduct();
				break;
				
			case "3":
				updateProduct();
				break;
			case "4":
				deleteProduct();
				
			}
			
			
		}
		
		//delete product
		
	private void deleteProduct() throws SQLException {
		System.out.println("Product id:");
		int itemid = input.nextInt();
		input.nextLine();
		
		database.deleteProduct(itemid);
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			productTable();
		}
		
	}

	//update product
	private void updateProduct() throws SQLException {
		System.out.println("Product id:");
		int itemid = input.nextInt();
		input.nextLine();
		
		System.out.println("Product name :");
		String name = input.nextLine();
		
		System.out.println("Quantity: ");
		int quantity = input.nextInt();
		input.nextLine();
		
		System.out.println("Price");
		double price = input.nextDouble();
		input.nextLine();
		
		database.updateProduct(itemid, name, quantity, price);
		
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			productTable();
		}
	}

	//create product
	private void createProduct() throws SQLException {
		
		System.out.println("Product id:");
		int itemid = input.nextInt();
		input.nextLine();
		
		System.out.println("Product name :");
		String name = input.nextLine();
		
		System.out.println("Quantity: ");
		int quantity = input.nextInt();
		input.nextLine();
		
		System.out.println("Price");
		double price = input.nextDouble();
		input.nextLine();
		
		database.createProduct(itemid, name, quantity, price);
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			productTable();
		}
	}

	//read product
	private void readProduct() throws SQLException {
		database.getConnection();
		database.readFullProduct();
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			productTable();
		}
			
			
		}
	
	
	//__________________________________Orders____________________________________
	
	public void orderTable() throws SQLException {
		System.out.println("0. Back \n" + "1. Read Orders Table\n" + "2. Create an Order\n" + " 3.Update Orders Details\n" + " 4 .Delete Orders");
		String options = input.nextLine();
		
		switch(options) {
		case "0":
			adminFirstPage();
			break;
		
		case "1":
			readOrder();
			break;
			
		
		case "2":
			createOrder();
			break;
			
		case "3":
			updateOrder();
			break;
		case "4":
			deleteOrder();
			
		}
	}
	

	private void deleteOrder() throws SQLException {
		System.out.println("Order ID:");
		int orderId = input.nextInt();
		input.nextLine();
		
		database.deleteOrder(orderId);
		
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			orderTable();
		}
	}

	private void updateOrder() throws SQLException {
		System.out.println("Order ID:");
		int orderId = input.nextInt();
		input.nextLine();
		
		System.out.println("Item ID: ");
		int itemId = input.nextInt();
		input.nextLine();
		
		System.out.println("Customer ID");
		int customerId = input.nextInt();
		input.nextLine();
		database.updateOrders(orderId, customerId, itemId);
		
	}

	// create orders
	private void createOrder() throws SQLException {
		System.out.println("Order ID:");
		int orderId = input.nextInt();
		input.nextLine();
		
		System.out.println("Item ID: ");
		int itemId = input.nextInt();
		input.nextLine();
		
		System.out.println("Customer ID");
		int customerId = input.nextInt();
		input.nextLine();
		
		database.createOrder(orderId, customerId, itemId);
		
			
	}

	// Read Orders
	private void readOrder() throws SQLException {
		database.getConnection();
		database.readOrder();
		System.out.println("/b Press 0 to go Back");
		String backbtn = input.nextLine();
		switch(backbtn) {
		case "0":
			customerTable();
		}
		
		
	}

	//-----------------Customer Functions------------------------//



	public void customerMenu() throws SQLException{
		
		database.getConnection();
		System.out.println("_________________________________________________\n");
		System.out.println("Welcome To customer page\n");
		System.out.println("_________________________________________________\n");
		customerFirstPage();
		
	}
	
	
	public void customerFirstPage() throws SQLException {
		System.out.println("Choose 1 for products\n" + "Choose 2 to Update Details \n"+ "Choose 0 to go back");
		String option = input.nextLine();
		
		switch(option) {
		case"0":
			mainMenu();
			break;
			
			
			case"1":
				viewProducts();
			break;
			
			case "2":
				updateCustomer();
				break;
		}
			
		
		
		}
	
	// View All the items
	public void viewProducts() throws SQLException {
		System.out.println("View all the products");
		database.readProduct();
		System.out.println("To go back press 0");
		String back = input.nextLine();
		switch(back) {
			case "0":
			customerFirstPage();
		}
	}
	
	//update customer details
	public void updateCustomer() throws SQLException {
		System.out.println("Update Customer Details");
		updateDetails();
		System.out.println("To go back press 0");
		String back = input.nextLine();
		switch(back) {
			case "0":
			adminFirstPage();
		}
			
	
		
	}
	
	
	
	
	}




