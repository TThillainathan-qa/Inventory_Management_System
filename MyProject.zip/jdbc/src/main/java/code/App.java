package code;

import java.sql.SQLException;

public class App {
	
	public static void main (String[] arg) throws SQLException {
		
		DB db = new DB();
		//db.create("tamil", "english");
		db.read();
	}

}
