package code;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {

	private Connection conn;
	
	private Statement stmnt;
	
	public DB() throws SQLException {
		conn = DriverManager.getConnection(DBConfig.URL, DBConfig.USER, DBConfig.PASSWORD);
	}
	
	
//	public void create(String fname, String lname) throws SQLException {
//		String sql = "INSERT INTO cutsomer_system_management VALUES('firstname', 'lastname') VALUES (" + fname + "" + lname + ")";
//		this.stmnt = conn.createStatement();		
//		this.stmnt.execute(sql);
//	}
//	
	
	public void read() throws SQLException {
		this.stmnt = conn.createStatement();
		String sql = "SELECT * FROM customer";
		ResultSet results =this.stmnt.executeQuery(sql );
		while (results.next()) {
			System.out.println(results.getString("first_name"));
		}
	}
	
	
	
//	public void update(String fname , String lname, int id) throws SQLException {
//		this.stmnt = conn.createStatement();
//		String sql = "UPDATE sakila SET first_name = " + fname + ", last_name = " + lname + "WHERE customer_id = " +id;
//		stmnt.executeQuery(sql);
//		
//	}
//	
//	public void delete(int id) throws SQLException {
//		this.stmnt = conn.createStatement();
//		String sql = "DELETE FROM sakila WHERE customer_id = " +id;
//		stmnt.executeQuery(sql);
//
//	}
}

