package code;

public final class DBConfig {
	
	public static final String USER = "root";
	
	public static final String PASSWORD = "root";
	
	public static final String URL = "jdbc:mysql://localhost/customer_management_system?serverTimezone=UTC";

}
